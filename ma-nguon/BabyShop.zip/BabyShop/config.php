<?php
    DEFINE('HOST','localhost');
    DEFINE('USER','root');
    DEFINE('PASS','');
    DEFINE('DB','babyshop');
?>