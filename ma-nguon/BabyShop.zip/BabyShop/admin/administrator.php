  <!----HEADER----->
 <?php require_once("inc/header.inc"); ?>
             
             <!----MIDDLE----->
            <div id="middle">
                 <?php require_once("inc/left_menu.inc"); ?> <!----MENU TRÁI----->
                <div id="main">               
                   <!----------------------CONTENT------------------------------->
           		    <?php require_once("dieuhuong.php"); ?>
                     <!-------------------------------------------------------------->
                </div>
            </div> <!--END MIIDLE-->
            <div class="clear"></div>
            
 <!----FOOTER----->
 <?php require_once("inc/footer.inc"); ?>